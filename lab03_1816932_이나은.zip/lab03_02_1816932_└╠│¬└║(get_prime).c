#include <stdio.h>

int main()
{
   int prime[1000];
   int i, j, k ;
   int line = 0;

   for (i = 0; i < 1000; i++) {
      prime[i] = 1;
   }

   prime[0] = 0; 
   prime[1] = 0;

   for (j = 2; j < 32; j++) {
      for (k = 2; k < 1000; k++) { 
         int sosux = j * k;
         if (sosux >= 1000) {
            break;
         }
         else {
            prime[sosux] = 0;
         }
      }
   }

   for (i = 0; i < 1000; i++) {
      if (prime[i] == 1) {
         printf("%4d", i);
         line++;
      }
      if (line == 15) {
         printf("\n");
         line = 0;
      }
   }
   printf("\n");
   return 0;
}