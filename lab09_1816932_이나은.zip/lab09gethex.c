#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <math.h>

char gethex(int six)
{
    char hexa[20];
    int tent = 0; 
	int i;
	scanf("%ld", &hexa);

    int position = 0;
    for (i = strlen(hexa) - 1; i >= 0; i--) 
    {
        char ch = hexa[i];   

        if (ch >= 48 && ch <= 57) 
        {
            tent += (ch - 48) * pow(16, position);
        }
        else if (ch >= 65 && ch <= 70)   
        {                                
            tent += (ch - (65 - 10)) * pow(16, position);
        }
        else if (ch >= 97 && ch <= 102)
        {
            tent += (ch - (97 - 10)) * pow(16, position);
        }

        position++;
    }

    printf("%d\n", tent);

    return 0;
}