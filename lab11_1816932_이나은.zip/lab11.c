#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct name{
	char first[20];
	char last[20];
};

struct date {
	char month[12];
	int day, year;
};

struct person {
	struct names name;
	struct date birthday;
};

int convert (char *mon){
	char *month[] = {"January","February","March","April","May","June","July",
		"August","September","October","November","December"};
	char *mon[] = {"1","2","3","4","5","6","7","8","9","10","11","12"};
}


main(int argc, char *argv[]){
	struct person cast[20];
	int ncast = 0;
	FILE *f;
	int i;

	if (argc<2){
		fprintf(stderr, "usage : %s filename\n", argv[0]);
		exit(1);
	}

	if ((f=fopen(argv[1],"r"))==NULL){
		fprintf(stderr, "%s : can't open %s\n", argv[0], argv[1]);
		exit(1);
	}


	while(1){
		if(fscanf(f, "%s %s %s %d %d", &first[ncast], &last[ncast], &month[ncast],
			&date[ncast], &year[ncast]) == EOF)
			break;
		ncast++;
	}

	fclose(f);

	printf("Cast of Captain America : Civil War\n");
	printf("=============================================\n\n");
	printf("Name   (Birthday)\n\n");
	for (i=0;i<ncast;i++)
		printf("%s, %s (%02d/%02d/%02d)\n",
							cast[i].name.last,
							cast[i].name.first,
							convert(cast[i].birthday.month),
							cast[i].birthday.day,
							cast[i].birthday.year % 100);
}