#include <stdio.h>
#include <ctype.h>

#define SIZE 100

int main(void){
	int n, a[SIZE];
	int geting(int *);
	int i, sum;

	for (n=0; n < SIZE && getint(&a[n]) != EOF; n++)
		;
	sum = 0;
	for ( i = 0; i n; i ++)
		sum += a[i];
	printf("The sum is %d\n", sum);
}