#define NUMBER '0'

void push(double);
double pop(void);
int getop(char[]);
int size(void);