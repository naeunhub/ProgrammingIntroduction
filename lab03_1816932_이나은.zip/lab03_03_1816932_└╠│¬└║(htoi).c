#include <stdio.h>
#include <string.h>

char ft, sd, c;

int htoi(char s[]) {

   int fv, st, i, v; 
   fv = st = 0 ;

    if (strlen(s) > 2) { 
      ft = s[0];
      sd = s[1];

      if (ft == '0' && (sd == 'x' || sd == 'X')) { 
         st = 2;
      }
   }

   for (i = st; (c = s[i]) != '\0'; i++) { 
      
      if ('0' <= c && c <= '9') {
         v = c - '0';
      }
      else if ('a' <= c && c <= 'f') {
         v = 10 + c - 'a';
      }
      else if ('A' <= c && c <= 'F') { 
         v = 10 + c - 'A';
      }
      
      fv = fv * 16 + v; 
   }
   return fv;
}

main()
{
   printf("AbCdEf ==> %d\n", htoi("AbCdEf"));
   printf("123456 ==> %d\n", htoi("123456"));
   printf("0100 ==> %d\n", htoi("0100"));
}