#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include "calc.h"
#define MAXOP 100

int main(void){
	int type;

	double op2;

	char s[MAXOP];
	char op[MAXOP];

	int size_n[MAXOP], op_size[MAXOP];
	int a=1, b,c=1;
	
	while((type=getop(s))!=EOF)
	{
		switch(type){
		case NUMBER:
				push (atof(s));
				size_n[c]=size();
				while(size_n[c] == op_size[a-1]+2&&size_n[c-1]==op_size[a-1]+1)
				{
					b=a;
					switch(op[b-1])
					{
						case '+':
							push(pop()+pop());
							break;
						case '*':
							push(pop()*pop());
							break;
						case '-':
							op2 = pop();
							push(pop()-op2);
							break;
						case '/':
							op2 = pop();
							if(op2!=0.0)
								push(pop()/op2);
							else
								printf("error: zero divisor\n");
							break;
					}
					a-=1;c-=1;
				}
				c++;
				break; 
			case '+':
				op_size[a] = size();
				op[a] = type;
				a++;
				break;

			case '*':
				op_size[a] = size();
				op[a] = type;
				a++;
				break;
							
			case '-':
				op_size[a] = size();
				op[a] = type;
				a++;
				break;
							
			case '/':
				op_size[a] = size();
				op[a] = type;
				a++;
				break;
			case'\n':
				printf("\t%.8g\n",pop());
				break;
		}
	}
}
