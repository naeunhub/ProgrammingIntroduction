#include <stdio.h>
#include <math.h>

int main()
{
    double n;
    double sum=0, variance=0, avg, sd;
    int count = 0;
   int result = 0;

    while(1)
    {
      result = scanf("%lf", &n);

        if(result == EOF)
        {
            break;
        }

        sum += n;
        variance += pow(n, 2.0);

        ++count;
    }

    avg = sum / (double)count;
    sd = sqrt((variance / count) - pow(avg, 2.0));

    printf("Avg = %f\n", avg);
    printf("Sd = %f\n", sd);

    return 0;
}